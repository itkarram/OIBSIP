<script>
        var x=document.getElementById('login');
        var y=document.getElementById('register');
        var z=document.getElementById('btn');
        function register()
        {
            x.style.left='-400px';
            y.style.left='50px';
            z.style.left='110px';
        }
        function login()
        {
            x.style.left='50px';
            y.style.left='450px';
            z.style.left='0px';
        }
    
    </script>
    <script>
        var modal=document.getElementById('login-form');
        window.onclick=function(event)
        {
            if(event.target==modal)
            {
                modal.style.display="none";
            }
        }
    </script>


const firebaseConfig = {
    apiKey: "AIzaSyCjzBUJPjRNy-L74w7-DzGvac2wGtuS618",
    authDomain: "cloud-federation.firebaseapp.com",
    databaseURL: "https://cloud-federation-default-rtdb.firebaseio.com",
    projectId: "cloud-federation",
    storageBucket: "cloud-federation.appspot.com",
    messagingSenderId: "200776223395",
    appId: "1:200776223395:web:55ff025c3a3e16116ecd16"
  };

  